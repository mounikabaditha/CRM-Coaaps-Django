# Django-CRM-mastery-app-Project-1-YT

Welcome to the Django-CRM-mastery-app!

Please ensure that you create your own virtual environment and install all the necessary packages via the requirements.txt file. 

Enjoy!

